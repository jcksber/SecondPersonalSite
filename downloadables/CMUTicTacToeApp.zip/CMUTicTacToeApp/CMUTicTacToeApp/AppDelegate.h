//
//  AppDelegate.h
//  CMUTicTacToeApp
//
//  Created by Jack Kasbeer on 5/15/13.
//  Copyright (c) 2013 Jack Kasbeer. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
