//
//  ActivityListViewController.h
//  KindergardenHereICome
//
//  Created by Chris Allwein on 11/15/13.
//  Copyright (c) 2013 PAEYC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActivityListViewController : UITableViewController

@property (strong, nonatomic)NSString *tag;

@end
