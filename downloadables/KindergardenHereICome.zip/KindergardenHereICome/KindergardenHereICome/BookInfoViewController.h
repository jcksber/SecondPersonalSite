//
//  BookInfoViewController.h
//  KindergardenHereICome
//
//  Created by Chris Allwein on 11/15/13.
//  Copyright (c) 2013 PAEYC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Book.h"

@interface BookInfoViewController : UIViewController

@property (strong, nonatomic)Book *book;

@end
