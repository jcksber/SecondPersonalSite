KindergardenHereICome
=====================

Prototype for an educational, interactive, structuring app for parents

PAEYC Hackathon - November 2013
