/**
 * @author Jack Kasbeer
 * @version 1.0
 * @title Tic Tac Toe Game
 */
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class TicTacToe extends JFrame{    
    private JButton[][] buttons;
    private static final int ROWS = 3;
    private static final int COLS = 3;
    private JPanel buttonPanel;
    private JMenu file;
    private JMenuItem quit, reset;
    private Font fontX, fontO;
    private String X, O;
    private int[][] counters;
    private String[] options = {"Yes", "No"};
    
    private static final int YES_NO_OPTION = 2;
    private boolean hasNullButton;

    /**
     * Constructs an empty board with blank buttons
     */
    public TicTacToe(){
        X = "X";
        O = "O";
        fontX = new Font(X,Font.BOLD,120);
        fontO = new Font(O,Font.BOLD,120);
        
        buttonPanel = new JPanel();
        setLayout(new BorderLayout());
        setSize(600,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        buttons = new JButton[ROWS][COLS];
        counters = new int[3][3];
        
        //Fills board with blank buttons
        buttonPanel.setLayout(new GridLayout(3,3));
        for (int i = 0; i < ROWS; i++){
            for (int j = 0; j < COLS; j++){
                buttons[i][j] = new JButton();
                buttonPanel.add(buttons[i][j]);
                buttons[i][j].setText(" ");
                buttons[i][j].setFont(fontX);
                buttons[i][j].setFont(fontO);
                buttons[i][j].addActionListener(new Listener(i,j));
            }
        }
        add(buttonPanel);
        JMenuBar myMenuBar = new JMenuBar();
        
        file = new JMenu("File");
        myMenuBar.add(file);
        file.addMenuListener(new FileListener());
        
        quit = new JMenuItem("Quit");
        file.add(quit);
        quit.addActionListener(new MenuActionListener());
        
        
        reset = new JMenuItem("Reset");
        file.add(reset);
        reset.addActionListener(new MenuActionListener());
        
        setJMenuBar(myMenuBar);
        setVisible(true);
        
        JOptionPane.showMessageDialog(null,"Welcome to Tic Tac Toe!");
    }
    
    /**
     * Checks for all possible ways of winning (8), and if someone
     * has won, it displays the win and prompts the user to play 
     * again or quit.
     */
    public void checkForWin(){  
        hasNullButton = false;
        //diagonal right
        if (buttons[0][0].getText().equals(buttons[1][1].getText()) && buttons[1][1].getText().equals(buttons[2][2].getText())){
            for (int i = 0; i <= 2; i++){
                if (buttons[i][i].getText().equals(" ")){
                    hasNullButton = true;
                }   
                else if (i == 2 && !hasNullButton){
                    buttons[i][i].setBackground(Color.BLUE);
                    repaint();
                    JOptionPane.showOptionDialog(null,buttons[i][i].getText() + " Wins!",null,YES_NO_OPTION,0,null, options, options[0]);
                }
            }
        }
        //diagonal left
        else if (buttons[0][2].getText().equals(buttons[1][1].getText()) && buttons[1][1].getText().equals(buttons[2][0].getText())){
            for (int i = 0; i <= 2; i++){
                for (int j = 2; j>= 0; j--){
                    if (buttons[i][j].getText().equals(" ")){
                        hasNullButton = true;
                        break;
                    }
                    else if (i == 2 && !hasNullButton){
                        buttons[i][j].setBackground(Color.BLUE);
                        JOptionPane.showOptionDialog(null,buttons[i][j].getText() + " Wins!",null,YES_NO_OPTION,0,null, options, options[0]);
                    }
                }
            }
        }
        //vertical left
        else if (buttons[0][0].getText().equals(buttons[1][0].getText()) && buttons[1][0].getText().equals(buttons[2][0].getText())){
            for (int i = 0; i <= 2; i++){
                if (buttons[i][0].getText().equals(" ")){
                    hasNullButton = true;
                    break;
                }
                else if (i == 2 && !hasNullButton){
                    buttons[i][0].setBackground(Color.RED);
                    JOptionPane.showOptionDialog(null,buttons[i][0].getText() + " Wins!",null,YES_NO_OPTION,0,null, options, options[0]);
                }
            }
        }
        //vertical middle
        else if (buttons[0][1].getText().equals(buttons[1][1].getText()) && buttons[1][1].getText().equals(buttons[2][1].getText())){
            for (int i = 0; i <= 2; i++){
                if (buttons[i][1].getText().equals(" ")){
                    hasNullButton = true;
                    break;
                }
                else if (i == 2 && !hasNullButton){
                    buttons[i][1].setBackground(Color.RED);
                    JOptionPane.showOptionDialog(null,buttons[i][1].getText() + " Wins!",null,YES_NO_OPTION,0,null, options, options[0]);
                }
            }
        }
        //vertical right
        else if (buttons[0][2].getText().equals(buttons[1][2].getText()) && buttons[1][2].getText().equals(buttons[2][2].getText())){
            for (int i = 0; i <= 2; i++){
                if (buttons[i][2].getText().equals(" ")){
                    hasNullButton = true;
                    break;
                }
                else if (i == 2 && !hasNullButton){
                    buttons[i][2].setBackground(Color.RED);
                    JOptionPane.showOptionDialog(null,buttons[i][2].getText() + " Wins!",null,YES_NO_OPTION,0,null, options, options[0]);
                }
            }
        }
        //horizantal top
        else if (buttons[0][0].getText().equals(buttons[0][1].getText()) && buttons[0][1].getText().equals(buttons[0][2].getText())){
            for (int i = 0; i <= 2; i++){
                if (buttons[0][i].getText().equals(" ")){
                    hasNullButton = true;
                    break;
                }
                else if (i == 2 && !hasNullButton){
                    buttons[0][i].setBackground(Color.GREEN);
                    JOptionPane.showOptionDialog(null,buttons[0][i].getText() + " Wins!",null,YES_NO_OPTION,0,null, options, options[0]);
                }
            }
        }
        //horizantal middle
        else if (buttons[1][0].getText().equals(buttons[1][1].getText()) && buttons[1][1].getText().equals(buttons[1][2].getText())){
            for (int i = 0; i <= 2; i++){
                if (buttons[1][i].getText().equals(" ")){
                    hasNullButton = true;
                    break;
                }
                else if (i == 2 && !hasNullButton){
                    buttons[1][i].setBackground(Color.GREEN);
                    JOptionPane.showOptionDialog(null,buttons[1][i].getText() + " Wins!",null,YES_NO_OPTION,0,null, options, options[0]);
                }
            }
        }
        //horizantal bottom
        else if (buttons[2][0].getText().equals(buttons[2][1].getText()) && buttons[2][1].getText().equals(buttons[2][2].getText())){
            for (int i = 0; i <= 2; i++){
                if (buttons[2][i].getText().equals(" ")){
                    hasNullButton = true;
                    break;
                }
                else if (i == 2 && !hasNullButton){
                    buttons[2][i].setBackground(Color.GREEN);
                    JOptionPane.showOptionDialog(null,buttons[2][i].getText() + " Wins!",null,YES_NO_OPTION,0,null, options, options[0]);
                }
            }
        }   
    }
    
    /**
     * Creates an actionListener for all of the buttons
     * (the board, essentially)
     * @Override _________________
     */
    private class Listener implements ActionListener{
        private int x,y;
        
        public Listener(int anX, int aY){
            x = anX;
            y = aY;
        }
        
        @Override
        public void actionPerformed(ActionEvent e){
            if (counters[x][y] == 0){
                buttons[x][y].setText("X");
            }
            else if (counters[x][y] == 1){                                                                                     
                buttons[x][y].setText("O");
            }
            else if (counters[x][y] == 2){
                buttons[x][y].setText(" ");
            }
            else {
                counters[x][y] = 0;
                buttons[x][y].setText("X");
            }
            counters[x][y]++;
            checkForWin();
        }
    }
    
    /**
     * Creates an actionListener for the "File" Menu
     * on the MenuBar
     * @Override _______________
     */
    private class FileListener implements MenuListener{
          
        @Override
        public void menuSelected(MenuEvent e){
            
        }
        
        @Override
        public void menuDeselected(MenuEvent e){
            
        }
        
        @Override
        public void menuCanceled(MenuEvent e){
            
        }
    }
    
    /**
     * Creates an actionListener for the MenuItems in 
     * the Menu
     * @Override ________________
     */
    private class MenuActionListener implements ActionListener{
        
        @Override
        public void actionPerformed(ActionEvent e){
            if (e.getActionCommand().equals("Quit")){
                System.exit(0);
            }
            else if (e.getActionCommand().equals("Reset")){
                for (int i = 0; i < ROWS; i++){
                    for (int j = 0; j < COLS; j++){
                         buttons[i][j].setText(" ");
                         counters[i][j] = 0;
                    }
                }   
            }   
        }
    }
}