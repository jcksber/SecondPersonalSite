/**
 * @author Jack Kasbeer
 * @version 1.0.1
 * @title Tic Tac Toe
 */
public class TicTacToePlayer{
    public static void main(String[] args){
         TicTacToe t = new TicTacToe();
    }
}