package card;
/**
 * @author Jack Kasbeer
 * Assignment #3
 * Tests the methods of Deck
 */

public class DeckTester{
    public static void main(String[] args){
        Deck d = new Deck();
        System.out.println(d);
        System.out.println(d.getNumberOfCards());
    }
}